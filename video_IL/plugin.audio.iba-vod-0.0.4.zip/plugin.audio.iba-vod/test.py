# -*- coding: utf-8 -*-
from api import API

api = API(None)


# print [i for i in (api.get_live())['liveBroadcasts'] if u'רשת א' in i['channelName']][0]
# print api.get_streaming_data('channel-511M')
# print api.get_channel_schedule(4)
# print api.get_channel_vod(1)
print api.get_program_vod('28/12/15', 1970907)